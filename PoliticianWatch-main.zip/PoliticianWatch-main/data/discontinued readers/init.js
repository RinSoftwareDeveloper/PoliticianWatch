// This is NOT used in official build.

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyABM-D8sf_NaJrQyXEJJb5WFBGZxPLbmqI",
  authDomain: "politicianwatch-cb301.firebaseapp.com",
  projectId: "politicianwatch-cb301",
  storageBucket: "politicianwatch-cb301.appspot.com",
  messagingSenderId: "889157523523",
  appId: "1:889157523523:web:ec266261416171fbd69cf6",
  measurementId: "G-WNR6D7RXXJ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
