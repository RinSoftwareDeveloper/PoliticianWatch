data = [];
document.getElementById('data.txt') = data;
