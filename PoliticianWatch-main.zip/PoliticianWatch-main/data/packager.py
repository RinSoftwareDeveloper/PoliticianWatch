f = open("node-officers.txt", "r")
print(f.read())


f.close()
