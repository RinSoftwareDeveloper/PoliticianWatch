import algo
# Make sure adding further rows is easy

for i in range(len(algo())):
	Name = algo()[1+i]
	Country = algo()[1+i]
	Company = algo()[1+i]
	
	print(f"""
	<tr>
		<td>{Name}</td>
	 	<td>{Country} - {DB}</td>
		<td>{Company}</td>
	</tr>
	""")
