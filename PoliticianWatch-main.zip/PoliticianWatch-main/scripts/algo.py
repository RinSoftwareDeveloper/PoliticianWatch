def algo():
	# scuffed algorithm starts here
	f = open('data', 'w')
	f.write('240056161|KONSTANTIN EDEL|Russian Federation|RUS|"Pandora Papers - Alemán| Cordero| Galindo & Lee')
	f.close()
	# This is for reading the data. Disable in prod.
	f = open('data', 'r')
	print(f.read())
	
	data = '240056161|KONSTANTIN EDEL|Russian Federation|RUS|"Pandora Papers - Alemán| Cordero| Galindo & Lee' #smple
	data = f.read()
	lines = []
	lines2 = []
	for i in range((data).count("\n")):
		lines.append(data).split('\n')
	for i in range(len(lines)):
		lines2.append(data).split('|')
	return(lines2)
	
	# Sample 1 for Future Expand
	pyscript.write('names', 'Names')
	pyscript.write('user1', 'Konstantin Edel')
	pyscript.write('user1_data1', 'Russia - Pandora Papers')
	pyscript.write('user1_data2', 'import_second_data')
	
	f.close()
