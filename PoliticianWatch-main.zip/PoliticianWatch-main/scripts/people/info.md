# people popups
These do not have to be auto generated because they only appear a few times throughout the entire website (as only a few corrupt politicians have profiles that are deductable through out DB.)
