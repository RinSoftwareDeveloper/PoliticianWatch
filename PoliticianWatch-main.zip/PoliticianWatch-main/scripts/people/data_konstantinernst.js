let info = "<img id = 'warning' src = 'img/flag.svg'>Konstantin Ernst <br> Aquired a 23% stake in a 1,000,000,000 dollar deal, money unknown, relations with Putin";

function data_konstantinernst() {
	console.log("Info!")
	document.getElementById("KonstantinErnst").innerHTML = info;
};

function data_out(){
	console.log("Fixed v3")
	document.getElementById("KonstantinErnst").innerHTML = "<img id = 'warning' src = 'img/flag.svg'>Konstantin Ernst";
}
